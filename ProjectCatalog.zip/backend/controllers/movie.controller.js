const db = require('../models');
const Movie = db.movies;

exports.create = (req, res) => {
  const { title, description, genre, year, director, mainActors, duration, rentalPrice, purchasePrice, posterUrl, rating } = req.body;

  Movie.create({ title, description, genre, year, director, mainActors, duration, rentalPrice, purchasePrice, posterUrl, rating })
    .then(movie => res.send(movie))
    .catch(err => res.status(500).send({ message: err.message }));
};

exports.getAll = (req, res) => {
  Movie.findAll().then(movies => res.send(movies));
};

exports.getOne = (req, res) => {
  const id = req.params.id;
  Movie.findByPk(id)
    .then(movie => {
      if (movie) {
        res.send(movie);
      } else {
        res.status(404).send({ message: "Movie not found!" });
      }
    });
};

exports.update = (req, res) => {
  const id = req.params.id;
  Movie.update(req.body, { where: { id } })
    .then(() => res.send({ message: "Movie updated successfully!" }))
    .catch(err => res.status(500).send({ message: err.message }));
};

exports.delete = (req, res) => {
  const id = req.params.id;
  Movie.destroy({ where: { id } })
    .then(() => res.send({ message: "Movie deleted successfully!" }))
    .catch(err => res.status(500).send({ message: err.message }));
};
