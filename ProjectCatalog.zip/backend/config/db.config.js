module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "",
  DB: "catalogo_peliculas",
  dialect: "mysql"
};
