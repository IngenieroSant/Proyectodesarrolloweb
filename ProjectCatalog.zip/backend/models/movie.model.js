module.exports = (sequelize, Sequelize) => {
  const Movie = sequelize.define("movie", {
    title: { type: Sequelize.STRING, allowNull: false },
    description: { type: Sequelize.STRING, allowNull: false },
    genre: { type: Sequelize.STRING, allowNull: false },
    year: { type: Sequelize.INTEGER, allowNull: false },
    director: { type: Sequelize.STRING, allowNull: false },
    mainActors: { type: Sequelize.STRING, allowNull: false },
    duration: { type: Sequelize.INTEGER, allowNull: false },
    rentalPrice: { type: Sequelize.FLOAT, allowNull: false },
    purchasePrice: { type: Sequelize.FLOAT, allowNull: false },
    posterUrl: { type: Sequelize.STRING, allowNull: false },
    rating: { type: Sequelize.FLOAT }
  });
  return Movie;
};
