export const environment = {
    apiUrl: 'https://fakestoreapi.com/'

};
