import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthResponse, Usuario } from '../interfaces/usuario';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  
  constructor(private readonly http: HttpClient, private router: Router) { }


  login(credenciales: Usuario): Observable<AuthResponse>{
    return this.http.post<AuthResponse>(environment.apiUrl + 'auth/login', credenciales)
  }

  setToken(token:string){
    localStorage.setItem('authToken', token)
  }

  logout(){
    localStorage.removeItem('authToken');
    this.router.navigateByUrl('/login')

  }
}
